const formulario = document.getElementById("formAluno");
const campoNome = document.getElementById("nome");
const campoEmail = document.getElementById("email");
const campoCurso = document.getElementById("curso");
const listaAlunos = document.getElementById("listaAlunos");
const mensagemVazia = document.getElementById("mensagemVazia");

const alunos = [];

formulario.addEventListener("submit", cadastrarAluno);

function cadastrarAluno(event) {
  event.preventDefault();

  const nome = campoNome.value.trim();
  const email = campoEmail.value.trim();
  const curso = campoCurso.value;

  const aluno = {
    nome: nome,
    email: email,
    curso: curso
  };

  alunos.push(aluno);
  mostrarAlunos();
  formulario.reset();
}

function mostrarAlunos() {
  listaAlunos.innerHTML = "";

  if (alunos.length === 0) {
    mensagemVazia.style.display = "block";
    return;
  }

  mensagemVazia.style.display = "none";

  alunos.forEach(function (aluno, indice) {
    const item = document.createElement("li");
    item.textContent = `${indice + 1}. ${aluno.nome} - ${aluno.email} - ${aluno.curso}`;
    listaAlunos.appendChild(item);
  });
}
